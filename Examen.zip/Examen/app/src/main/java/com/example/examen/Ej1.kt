package com.example.examen

import android.content.Intent
import android.content.res.TypedArray
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcelable
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.parcelize.Parcelize
import java.util.ArrayList


class Ej1 : AppCompatActivity() {

    @Parcelize
    data class Planeta(val nombre:String,val tipo:String, val foto:Int): Parcelable


    lateinit var adap:adaptador

    lateinit var rv: RecyclerView


    lateinit var nombres:List<String>
    lateinit var tipos:List<String>
    lateinit var imagenes: TypedArray
    var planetas = mutableListOf<Planeta>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ej1)


        nombres= resources.getStringArray(R.array.ej1_planetas_nombres).toList()
        tipos= resources.getStringArray(R.array.ej1_planetas_tipo).toList()
        imagenes=resources.obtainTypedArray(R.array.ej1_planetas_img)

        nombres.forEachIndexed { i,e ->
            planetas.add(
                Planeta(e, tipos[i], imagenes.getResourceId(i, R.drawable.tierra))
            )
        }
    }

    override fun onStart() {
        super.onStart()
        rv = findViewById(R.id.rv_planetas)

        adap = adaptador(planetas, this)
        rv.adapter = adap
        rv.layoutManager = LinearLayoutManager(this)
    }
    fun deleteItem(pos:Int){
        planetas.removeAt(pos)
        adap.notifyItemRemoved(pos)
        adap.notifyItemRangeChanged(pos,planetas.size)
    }
    fun verPlaneta(pos:Int){
        val intent = Intent(this, Ej1b::class.java)
        intent.putExtra("PLANETA", planetas[pos])
        startActivity(intent)
    }


}