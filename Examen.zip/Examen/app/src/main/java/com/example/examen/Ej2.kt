package com.example.examen

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.android.material.textfield.TextInputLayout
import org.w3c.dom.Text
import java.io.Serializable
import java.util.concurrent.atomic.AtomicInteger

class Ej2 : AppCompatActivity() {

    companion object{
        val app_id = "com.example.pm_simulacroexamen2"
    }

    lateinit var SP: SharedPreferences

    val sp_timer_name = app_id+"_bombatron"

    var contador = 0L
    lateinit var cuentaAtras: TextView
    lateinit var Boom:ImageView
    lateinit var ct: CountDownTimer
    lateinit var btn_go: Button
    lateinit var cuenta_sin_solu:TextView
    lateinit var btn_desactivar: Button
    lateinit var btn_confing:Button
    lateinit var info:TextView
    lateinit var til_usuario:TextInputLayout
    var resultado=1
    lateinit var in_result:EditText

    var notisOn=false
    var desactivar=false

    lateinit var generador: AtomicInteger

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ej2)
        generador=AtomicInteger(0)
    }
    override fun onStart() {
        super.onStart()


        Boom=findViewById(R.id.tv_boom)
        btn_go=findViewById(R.id.btn_inicar)
        btn_desactivar=findViewById(R.id.btn_des)
        cuenta_sin_solu=findViewById(R.id.tv_cuenta)
        info=findViewById(R.id.tv_info)
        btn_confing=findViewById(R.id.ir_config)
        til_usuario=findViewById(R.id.til_user)

        cuentaAtras = findViewById(R.id.tv_cuentaAtras)
        cuentaAtras.text = contador.toString()

        in_result=findViewById(R.id.resul_user)

        Boom.visibility= View.INVISIBLE
        info.visibility= View.INVISIBLE
        til_usuario.visibility= View.INVISIBLE
        btn_desactivar.visibility= View.INVISIBLE
        cuenta_sin_solu.visibility= View.INVISIBLE
        cuentaAtras.visibility= View.INVISIBLE
        in_result.visibility= View.INVISIBLE

        SP= getSharedPreferences(sp_timer_name, 0)

        contador=SP.getInt(resources.getString(R.string.timer), resources.getInteger(R.integer.tiempodef)).toLong()
        notisOn=SP.getBoolean(resources.getString(R.string.notisOn), resources.getBoolean(R.bool.notisdef))
        desactivar=SP.getBoolean(resources.getString(R.string.desactivar), resources.getBoolean(R.bool.desactivardef))
        var contador_timer=contador*1000


        btn_confing.setOnClickListener {
            val inten=Intent(applicationContext, configruacion::class.java)
            startActivity(inten)
        }
        btn_go.setOnClickListener{
            resultado=generarCuenta()
            Boom.visibility= View.INVISIBLE
            contador=SP.getInt(resources.getString(R.string.timer), resources.getInteger(R.integer.tiempodef)).toLong()
            if(desactivar==true){
            info.visibility= View.VISIBLE
            btn_desactivar.visibility= View.VISIBLE
            cuenta_sin_solu.visibility= View.VISIBLE
            til_usuario.visibility= View.VISIBLE
            cuentaAtras.visibility= View.VISIBLE
            in_result.visibility= View.VISIBLE
            in_result.setText("")
            }
            ct = object : CountDownTimer(contador_timer, 1000) {

                override fun onTick(millisUntilFinished: Long) {
                    contador--
                    cuentaAtras.text = contador.toString()
                }

                override fun onFinish() {
                    if (notisOn==true){
                        generarNotificacion()
                        esconder()
                        in_result.visibility= View.INVISIBLE
                    }else{
                        esconder()
                        Boom.visibility= View.VISIBLE
                    }

                }
            }.start()
        }

        btn_desactivar.setOnClickListener {
            if(in_result.text.toString()!=""){
                igual(in_result.text.toString().toInt(),resultado)
            }

        }

    }

    override fun onPause() {
        super.onPause()

    }

    fun igual(user_val:Int, cuenta_solu:Int){
        if(user_val==cuenta_solu){
            ct.cancel()
            esconder()

        }else{
            esconder()
            Boom.visibility= View.VISIBLE
        }
    }

    fun generarCuenta(): Int {

        var n1 =(0..10).random()
        var n2 =(0..10).random()
        var x=n1
        var y=n2
        var oper = (1..3).random()
        var result=0

        if (n2>n1){
            n1=y
            n2=x
        }

        if (oper == 1){
            cuenta_sin_solu.text=n1.toString() + " + "+ n2.toString()
            result=n1+n2
        }else if(oper == 2){
            cuenta_sin_solu.text=n1.toString() + " - "+ n2.toString()
            result=n1-n2
        }else{
            cuenta_sin_solu.text=n1.toString() + " * "+ n2.toString()
            result=n1*n2
        }
        return result
    }
    private fun generarNotificacion() {
        val id = MainActivity.create_notification_id()

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, 0)

        val intent2 = Intent(this, Ej2::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent2 = PendingIntent.getActivity(this, 0, intent2, 0)

        val builder = NotificationCompat.Builder(this, MainActivity.CHANNEL_ID)
            .setSmallIcon(R.drawable.boom)
            .setContentTitle("LA BOMBA HA EXPLOTADO NOOO")
            .setContentText("BOOOOOM")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)


        with(NotificationManagerCompat.from(this)) {
            // el id debe de ser único para cada notificación y te servirá para hacer referencia
            // a dicha notificación en el futuro
            notify(id, builder.build())
        }
    }
    fun esconder(){
        til_usuario.visibility= View.INVISIBLE
        info.visibility= View.INVISIBLE
        btn_desactivar.visibility= View.INVISIBLE
        cuenta_sin_solu.visibility= View.INVISIBLE
        cuentaAtras.visibility= View.INVISIBLE
        in_result.visibility= View.INVISIBLE
    }
}