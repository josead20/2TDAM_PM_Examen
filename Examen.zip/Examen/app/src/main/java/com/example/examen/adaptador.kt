package com.example.examen

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.ArrayList

class adaptador (val lista:List<Ej1.Planeta>, val con:Context):
    RecyclerView.Adapter<adaptador.ViewHolder>()  {

    class ViewHolder(v : View): RecyclerView.ViewHolder(v){
        //var con elementos de la interfaz del rv
        var nombre: TextView
        var imagen: ImageView
        var btn_Borrar: Button

        init {
            //inicializamos los elementos de la interfaz
            nombre = v.findViewById(R.id.tv_datos)
            imagen = v.findViewById(R.id.tv_imagen)
            btn_Borrar=v.findViewById(R.id.btn_borrar)

        }
    }

    override fun onCreateViewHolder
                (parent: ViewGroup,
                 viewType: Int
    ): ViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.row_recycler, parent, false)
        return  ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        //pones los elementos en la interfaz :)

        val p = lista[position]
        holder.itemView.setOnClickListener{
            (con as Ej1).verPlaneta(position)
        }
        holder.nombre.text=p.nombre+"("+p.tipo+")"
        holder.imagen.setImageResource(p.foto)
        holder.btn_Borrar.setOnClickListener{
            (con as Ej1).deleteItem(position)
        }
    }
    override fun getItemCount(): Int {
        return lista.size
    }
}
