package com.example.examen

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast

class configruacion : AppCompatActivity() {

    lateinit var sw_noti:Switch
    lateinit var sw_desactivar:Switch
    lateinit var in_tiempo:EditText

    lateinit var SP:SharedPreferences

    val sp_timer_name = Ej2.app_id+"_bombatron"
    var tiempo_def=0
    var notisOn=false
    var desactivar=false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configruacion)
    }

    override fun onStart() {
        super.onStart()

        SP= getSharedPreferences(sp_timer_name, 0)

        sw_noti=findViewById(R.id.sw_noti)
        sw_desactivar=findViewById(R.id.sw_desacti)
        in_tiempo=findViewById(R.id.in_new_timer)

        tiempo_def=SP.getInt(resources.getString(R.string.timer), resources.getInteger(R.integer.tiempodef))
        notisOn=SP.getBoolean(resources.getString(R.string.notisOn), resources.getBoolean(R.bool.notisdef))
        desactivar=SP.getBoolean(resources.getString(R.string.desactivar), resources.getBoolean(R.bool.desactivardef))

        sw_noti.isChecked=notisOn
        sw_desactivar.isChecked=desactivar

        in_tiempo.setText(tiempo_def.toString())
    }

    override fun onBackPressed() {
        guardar_SP()
        val ir_bomba=Intent(applicationContext, Ej2::class.java)
        startActivity(ir_bomba)
    }

    fun guardar_SP(){
        if (in_tiempo.text.toString().toInt()==0){
            Toast.makeText(this, "El tiempo no puede ser 0", Toast.LENGTH_SHORT).show()}

        with(SP.edit()){
            putInt(resources.getString(R.string.timer), in_tiempo.text.toString().toInt())
            putBoolean(resources.getString(R.string.desactivar), sw_desactivar.isChecked)
            putBoolean(resources.getString(R.string.notisOn),  sw_noti.isChecked)
            commit()
        }

        Toast.makeText(applicationContext, "Configuracion guardada", Toast.LENGTH_SHORT).show()
        val ir_main= Intent(applicationContext, MainActivity::class.java)
        startActivity(ir_main)



    }
}