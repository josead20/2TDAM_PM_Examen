package com.example.examen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Ej3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ej3)
    }
}