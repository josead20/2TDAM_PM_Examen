package com.example.examen

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class Ej1b : AppCompatActivity() {

    lateinit var tv_nombre:TextView
    lateinit var tv_tipo:TextView
    lateinit var planeta_imagen:ImageView

    lateinit var planeta:Ej1.Planeta

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ej1b)

        tv_nombre=findViewById(R.id.tv_nombre_ej1)
        tv_tipo=findViewById(R.id.tv_tipo_ej1)
        planeta_imagen=findViewById(R.id.iv_imagen_ej1)

        planeta = intent.getParcelableExtra<Ej1.Planeta>("PLANETA")?:Ej1.Planeta("debug","",0)

        tv_nombre.text=planeta.nombre
        tv_tipo.text=planeta.tipo
        planeta_imagen.setImageResource(planeta.foto)

    }
}